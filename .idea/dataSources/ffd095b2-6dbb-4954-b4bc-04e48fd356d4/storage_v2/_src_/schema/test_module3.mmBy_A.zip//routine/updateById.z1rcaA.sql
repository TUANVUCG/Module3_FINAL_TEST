create
    definer = root@localhost procedure updateById(IN id int, IN N_name varchar(255), IN N_price float, IN N_amount int,
                                                  IN N_color varchar(255), IN N_description varchar(255),
                                                  IN N_category int)
begin
    update products
    set productName = N_name,
        price       = N_price,
        amount      = N_amount,
        color       = N_color,
        description = N_description,
        category    = N_category
    where productId = id;
end;

