create definer = root@localhost view findsubhavemaxmark as
select `baitap20_05_21`.`mark`.`SubID` AS `SubHaveMaxMark`, max(`baitap20_05_21`.`mark`.`Mark`) AS `MAX(mark)`
from `baitap20_05_21`.`mark`;

