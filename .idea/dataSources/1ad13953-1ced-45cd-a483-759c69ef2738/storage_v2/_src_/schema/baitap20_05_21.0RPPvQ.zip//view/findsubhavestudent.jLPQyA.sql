create definer = root@localhost view findsubhavestudent as
select `sub`.`SubID` AS `SubIDHaveStudent`
from (`baitap20_05_21`.`subject` `sub`
         join `baitap20_05_21`.`mark` `m` on ((`m`.`SubID` = `sub`.`SubID`)));

