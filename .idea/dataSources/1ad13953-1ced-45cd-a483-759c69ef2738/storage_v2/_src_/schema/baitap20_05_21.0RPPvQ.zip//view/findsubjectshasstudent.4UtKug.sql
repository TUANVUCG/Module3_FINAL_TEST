create definer = root@localhost view findsubjectshasstudent as
select `s`.`SubID` AS `SubID`, `s`.`SubName` AS `SubName`, `s`.`Credit` AS `Credit`, `s`.`Status` AS `Status`
from (`baitap20_05_21`.`subject` `s`
         join `baitap20_05_21`.`mark` `m` on ((`m`.`SubID` = `s`.`SubID`)));

